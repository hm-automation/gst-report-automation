# GST Report Automation

Automation tool for GST reconciliation, TDS/TCS reporting and Excel settlement processing.

## Overview

This project helps automate:
- GST reconciliation
- Settlement processing
- TDS/TCS reporting
- SKU profitability analysis
- Excel workflow automation

## Features

### GST Reconciliation
- Match sales and settlement data
- GST summary generation
- Tax validation workflows

### Settlement Processing
- Marketplace settlement analysis
- Return adjustment tracking
- Net settlement calculations

### TDS/TCS Reporting
- TDS tracking
- TCS reconciliation
- Settlement adjustment reports

## Technologies Used
- Excel
- VBA
- HTML
- JavaScript
- CSV Processing

## Author
Hardik Mavani
